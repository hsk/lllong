../lllc program.lll opengl.lll -o program -framework OpenGL -framework glut
